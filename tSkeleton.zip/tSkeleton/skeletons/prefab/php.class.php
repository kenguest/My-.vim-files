<?php
/**
 * @package:     <+FILE NAME ROOT:s/\.class$//+>
 * @author:      <+AUTHOR+> (<+EMAIL+>)
 * @license:     <+LICENSE+>
 * @created:     <+DATE+>.
 * @last change: 19-M�r-2005.
 * @version:     0.0
 * Description:
 * Usage:
 * TODO:
 * CHANGES:
 * 
 */

class <+FILE NAME ROOT:s/\.class$//+> extends <+CURSOR+> {
    function <+FILE NAME ROOT:s/\.class$//+>() {
        <+BODY+>
    }
    
    function <+METHOD+>() {
        <+BODY+>
    }
    
}
    
?>
